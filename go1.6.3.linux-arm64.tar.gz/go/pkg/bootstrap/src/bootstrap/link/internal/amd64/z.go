// Do not edit. Bootstrap copy of /build/go/src/cmd/link/internal/amd64/z.go

//line /build/go/src/cmd/link/internal/amd64/z.go:1
package amd64
